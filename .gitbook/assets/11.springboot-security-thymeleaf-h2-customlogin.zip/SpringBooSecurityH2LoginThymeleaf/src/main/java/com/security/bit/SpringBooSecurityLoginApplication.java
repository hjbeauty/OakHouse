package com.security.bit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBooSecurityLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBooSecurityLoginApplication.class, args);
	}

}
