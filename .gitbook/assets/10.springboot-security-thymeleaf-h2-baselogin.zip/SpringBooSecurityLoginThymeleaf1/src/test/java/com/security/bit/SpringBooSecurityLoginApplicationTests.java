package com.security.bit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBooSecurityLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
