package com.security.bit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBooSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
