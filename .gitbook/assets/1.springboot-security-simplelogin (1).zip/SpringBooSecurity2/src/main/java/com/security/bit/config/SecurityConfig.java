package com.security.bit.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
@Configuration
@EnableWebSecurity
class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// 모든 요청에 대해 인증이 되어야한다 . 인증할때 로그인페이지를 사용하겠다 
		http.authorizeRequests()
			.anyRequest().authenticated()
		  .and() 
		  	  .formLogin() 
		  	  	.loginPage("/login")
		  	    .permitAll();// login을 위해 모든 사용자들에게 접속허용
 	}
}









