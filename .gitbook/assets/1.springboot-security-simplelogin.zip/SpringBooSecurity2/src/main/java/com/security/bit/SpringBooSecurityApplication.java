package com.security.bit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBooSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBooSecurityApplication.class, args);
	}

}
